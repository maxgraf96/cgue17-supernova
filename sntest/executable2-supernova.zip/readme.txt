Group: Supernova
Fabian Fr�schl (1552749) and Max Graf (1527246)

Tested on: NVIDIA